/* 
 * This file is part of fmcs.
 * Copyright David Rushing Dewhurst, 2022 - present.
 * Some rights reserved.
 */

#include <cassert>
#include <chrono>
#include <cmath>
#include <functional>
#include <iostream>
#include <limits>
#include <optional>
#include <random>
#include <string>
#include <variant>
#include <vector>

#include <distributions.hpp>
#include <effects.hpp>
#include <inference/inference.hpp>
#include <inference/proposal.hpp>
#include <inference/metropolis/base.hpp>
#include <plate.hpp>
#include <record.hpp>

std::minstd_rand file_rng(202);

struct my_state {
    std::minstd_rand rng;
    double data;

    my_state(double data)
        : rng(2022), data(data) {}

};

double my_pp(record_t<DTypes<Normal, Gamma>>& r, std::shared_ptr<my_state> state) {
    auto loc = sample(r, "loc", Normal(0.0, 3.0), state->rng);
    auto scale = sample(r, "scale", Gamma(), state->rng);
    auto obs = observe(r, "obs", Normal(loc, scale), state->data);
    return std::pow(obs, 2.0);
}

int test_ancestor() {

    auto s = std::make_shared<my_state>(-3.0);
    pp_t<std::shared_ptr<my_state>, double, Normal, Gamma> f = my_pp;
    auto q = weighted_mean<double, Normal, Gamma>("loc");

    size_t thin = 25;
    size_t burn = 500;
    size_t nsamp = 25;
    auto opts = inf_options_t(thin, burn, burn + thin * nsamp);
    auto infer1 = inference<AncestorMetropolis>(f, *q, opts);
    auto start_time = std::chrono::high_resolution_clock::now();
    auto post_mean = infer1(s);
    auto elapsed = std::chrono::high_resolution_clock::now() - start_time;
    auto millis = std::chrono::duration_cast<std::chrono::milliseconds>(elapsed).count();
    
    std::cout << "Posterior mean = " << post_mean << std::endl;
    std::cout << "computed posterior marginal mean in " << millis << " milliseconds" << std::endl;

    auto record_q = weighted_record<double, Normal, Gamma>();
    auto infer2 = inference<AncestorMetropolis>(f, *record_q, opts);
    start_time = std::chrono::high_resolution_clock::now();
    auto some_records = infer2(s);
    elapsed = std::chrono::high_resolution_clock::now() - start_time;
    millis = std::chrono::duration_cast<std::chrono::milliseconds>(elapsed).count();
    std::cout << "computed posterior over records in " << millis << " milliseconds" << std::endl;

    auto r_samp = some_records->sample(s->rng);
    std::cout << "Sampled record:\n" << display(*r_samp) << std::endl;

    return 0;
}

template<typename RNG>
double my_discrete_pp(record_t<DTypes<Normal, Discrete<int>>>& r, int data, RNG& rng) {
    auto x = sample(r, "x", Normal(0.0, 3.0), rng);
    double p = 1.0 / (1.0 + std::exp(-x));
    std::vector<double> probs = {p, 1.0 - p};
    std::vector<int> items = {-1, 1};
    auto obs = observe(r, "obs", Discrete<int>(probs, items), data);
    return p;
}

int test_discrete_ancestor() {
    std::minstd_rand rng(2024);
    pp_t<int, double, Normal, Discrete<int>> df = [&rng](record_t<DTypes<Normal, Discrete<int>>>& r, int data) {
        return my_discrete_pp(r, data, rng);
    };
    auto q = weighted_mean<double, Normal, Discrete<int>>("x");

    size_t thin = 5;
    size_t burn = 5000;
    size_t nsamp = 25;
    auto opts = inf_options_t(thin, burn, burn + thin * nsamp);;
    auto infer1 = inference<AncestorMetropolis>(df, *q, opts);

    int data = -1;
    auto post_mean = infer1(data);

    std::cout << "Posterior mean = " << post_mean << std::endl;

    return 0;
}

struct my_kernel {
    enum class which_one {loc, scale};
    which_one last = which_one::loc;

    my_kernel() = default;

    double operator()(record_t<DTypes<Normal, Gamma>>& new_r, record_t<DTypes<Normal, Gamma>>& r) {
        if (last == which_one::loc) {
            double last_scale = std::visit([](auto& n){ return n.value; }, r.map["scale"]);
            // propose a log scale value and then exp
            auto prop = Normal(last_scale, 0.25);
            auto value = prop.sample(file_rng);
            transfer(
                new_r,
                "scale",
                    (node_t<Gamma>) {
                        .value = std::exp(value),
                        .logprob = prop.logprob(value),
                        .obs = false,
                        .interp = NodePropose()
                    }
            );
            last = which_one::scale;
        } else {
            double last_loc = std::visit([](auto& n){ return n.value; }, r.map["loc"]);
            auto prop = Normal(last_loc, 0.25);
            auto value = prop.sample(file_rng);
            transfer(
                new_r,
                "loc",
                (node_t<Normal>) {
                    .value = value,
                    .logprob = prop.logprob(value),
                    .obs = false,
                    .interp = NodePropose()
                }
            );
            last = which_one::loc;
        }
        return loglatent(new_r);
    }
};

int test_generic() {

    endog_proposal_t<Normal, Gamma> k = my_kernel();
    auto s = std::make_shared<my_state>(3.0);
    pp_t<std::shared_ptr<my_state>, double, Normal, Gamma> f = my_pp;
    auto q = weighted_mean<double, Normal, Gamma>("scale");

    size_t thin = 100;
    size_t burn = 10000;
    size_t nsamp = 250;
    auto opts = inf_options_t(thin, burn, burn + thin * nsamp);
    auto infer1 = inference<GenericMetropolis>(f, *q, opts);
    auto start_time = std::chrono::high_resolution_clock::now();
    auto post_mean_scale = infer1(s, k);
    auto elapsed = std::chrono::high_resolution_clock::now() - start_time;
    auto millis = std::chrono::duration_cast<std::chrono::milliseconds>(elapsed).count();
    
    std::cout << post_mean_scale << std::endl;
    std::cout << "computed posterior marginal mean scale in " << millis << " milliseconds" << std::endl;

    // demonstrate with a different queryer
    auto q_prob = probability<double, Normal, Gamma>(
        [](record_t<DTypes<Normal, Gamma>>& r) -> bool {
            auto n = std::get<node_t<Gamma>>(r["scale"].value());
            return n.value >= 2.5;
        }
    );
    auto infer2 = inference<GenericMetropolis>(f, *q_prob, opts);
    auto post_prob = infer2(s, k);
    std::cout << "Pr(scale > 2.5) = " << post_prob << std::endl;

    return 0;
}

template<size_t N>
double var_dice_model(record_t<DTypes<Normal, static_plate<Categorical, N>>>& r, double obs_value) {
    auto dice_values = sample(r, "dice_values", static_plate<Categorical, N>(6), file_rng);
    double value = 0.0;
    for (size_t ix = 0; ix != N; ix++) {
        value += sample(r, "payoff " + std::to_string(ix), Normal(0.0, 1 + dice_values->at(ix)), file_rng);
    }
    return observe(r, "value", Normal(value, 1.0), obs_value);
}

int test_plate_ancestor() {
    constexpr size_t dim = 4;
    auto q = weighted_mean<double, Normal, static_plate<Categorical, dim>>("payoff 2");
    size_t thin = 25;
    size_t burn = 500;
    size_t nsamp = 25;
    auto opts = inf_options_t(thin, burn, burn + thin * nsamp);

    double obs_value = -3.0;  // bad luck!
    pp_t<double, double, Normal, static_plate<Categorical, dim>> f = var_dice_model<dim>;
    auto infer = inference<AncestorMetropolis>(f, *q, opts);
    auto post_mean = infer(obs_value);
    std::cout << "posterior mean of payoff from dice 2 is " << post_mean << std::endl;

    return 0;
}

int main(int argc, char ** argv) {
    auto status = std::vector<int>({
        test_ancestor(),
        test_discrete_ancestor(),
        test_generic(),
        test_plate_ancestor()
    });
    if (*std::max_element(status.begin(), status.end()) > 0) {
        std::cout << "~~~ Test failed; read log for more. ~~~\n";
        return 1;
    } else {
        std::cout << "~~~ All tests passed. ~~~\n";
        return 0;
    }
}