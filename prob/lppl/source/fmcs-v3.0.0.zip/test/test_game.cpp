/*
 * This file is part of fmcs.
 * Copyright David Rushing Dewhurst, 2026 - present.
 * Some rights reserved.
 */

#include <game_distributions.hpp>
#include <record.hpp>
#include <inference/inference.hpp>
#include <inference/importance/likelihood.hpp>
#include <query.hpp>

#include <cmath>
#include <iostream>
#include <memory>
#include <optional>
#include <random>
#include <string>
#include <vector>

#define CHECK(cond, detail_lambda)                                        \
    do {                                                                  \
        if (!(cond)) {                                                    \
            std::cout << "  [FAIL] " << __FILE__ << ":" << __LINE__       \
                      << " -- assertion `" #cond "' is false."             \
                      << std::endl;                                        \
            std::cout << "  detail: ";                                    \
            detail_lambda();                                              \
            std::cout << std::endl << std::endl;                           \
            return 1;                                                     \
        }                                                                 \
    } while (0)

std::minstd_rand rng(2026);

// classic prisoner's dilemma, actions: 0 = cooperate, 1 = defect
std::vector<std::vector<double>> pd_row = { {-1.0, -3.0}, {0.0, -2.0} };
std::vector<std::vector<double>> pd_col = { {-1.0, 0.0}, {-3.0, -2.0} };

int test_prisoners_dilemma() {
    std::cout << "~~~ QRE on prisoner's dilemma ~~~" << std::endl;

    // lambda = 0: maximum entropy, exactly uniform
    auto g0 = NormalFormGame(pd_row, pd_col, 0.0);
    std::cout << g0.string() << std::endl;
    if (std::fabs(g0.action_probs(0)[0] - 0.5) > 1e-12) return 1;

    // lambda large: defect is strictly dominant, QRE -> defect w.p. ~1
    auto g8 = NormalFormGame(pd_row, pd_col, 8.0);
    std::cout << g8.string() << std::endl;
    std::cout << "Pr(cooperate | lambda=8) = " << g8.action_probs(0)[0] << std::endl;
    if (g8.action_probs(0)[1] < 0.99) return 1;
    if (!g8.converged) return 1;

    return 0;
}

// matching pennies: unique mixed NE at (0.5, 0.5), and QRE stays there for all lambda
int test_matching_pennies() {
    std::cout << "~~~ QRE on matching pennies ~~~" << std::endl;

    std::vector<std::vector<double>> mp_row = { {1.0, -1.0}, {-1.0, 1.0} };
    std::vector<std::vector<double>> mp_col = { {-1.0, 1.0}, {1.0, -1.0} };

    for (double lam : {0.5, 2.0, 8.0, 32.0}) {
        auto g = NormalFormGame(mp_row, mp_col, lam);
        std::cout << "lambda=" << lam << ": " << g.string() << std::endl;
        // zero-sum symmetry pins QRE at the uniform mixed profile
        if (std::fabs(g.action_probs(0)[0] - 0.5) > 1e-6) return 1;
        if (std::fabs(g.action_probs(1)[0] - 0.5) > 1e-6) return 1;
        if (std::fabs(g.expected_payoff(0)) > 1e-6) return 1;  // value of the game ~ 0
    }
    return 0;
}

// stag hunt: multiple equilibria; QRE branch from uniform selects the risk-dominant one
int test_stag_hunt() {
    std::cout << "~~~ QRE on stag hunt (equilibrium selection) ~~~" << std::endl;

    // stag payoff-dominant AND risk-dominant: QRE -> stag
    std::vector<std::vector<double>> sh1 = { {3.0, 0.0}, {0.0, 2.0} };
    // hare risk-dominant: QRE -> hare
    std::vector<std::vector<double>> sh2 = { {2.0, 0.0}, {0.0, 3.0} };

    auto g1 = NormalFormGame(sh1, sh1, 12.0);
    if (g1.action_probs(0)[0] <= 0.5) return 1;  // selects stag

    auto g2 = NormalFormGame(sh2, sh2, 12.0);
    std::cout << "hare-risk-dominant game: Pr(stag) = "
              << g2.action_probs(0)[0] << std::endl;
    if (g2.action_probs(0)[0] >= 0.5) return 1;  // selects hare

    return 0;
}

// empirical sampling frequencies should match the solved QRE
int test_sampling_consistency() {
    std::cout << "~~~ sampling from a game node ~~~" << std::endl;

    double lam = 2.0;
    auto g = NormalFormGame(pd_row, pd_col, lam);
    size_t niter = 20000;
    std::vector<size_t> counts = {0, 0, 0, 0};
    for (size_t ix = 0; ix != niter; ++ix) {
        auto profile = g.sample(rng);
        counts[profile[0] * 2 + profile[1]]++;
    }
    for (size_t a = 0; a != 2; ++a) {
        for (size_t b = 0; b != 2; ++b) {
            double emp = counts[a * 2 + b] / static_cast<double>(niter);
            double theo = g.action_probs(0)[a] * g.action_probs(1)[b];
            std::cout << "p((" << a << "," << b << ")) empirical = " << emp
                      << ", theoretical = " << theo << std::endl;
            if (std::fabs(emp - theo) > 0.02) return 1;
            double lp = g.logprob(nfg_profile_t {a, b});
            if (std::fabs(std::exp(lp) - theo) > 1e-9) return 1;
        }
    }
    return 0;
}

// payoffs are random variables; the game is solved *inside* the program
// observed play is optional data at the game node
nfg_profile_t coordination_model(
    record_t<DTypes<Normal, NormalFormGame>>& r,
    std::optional<nfg_profile_t> observed_play
) {
    auto gain = sample(r, "gain", Normal(2.0, 1.0), rng);
    auto safe = sample(r, "safe", Normal(1.0, 0.25), rng);
    std::vector<std::vector<double>> u = { {gain, 0.0}, {0.0, safe} };

    auto game = NormalFormGame(u, u, 4.0);

    return sample(r, "play", game, rng, observed_play);
}

// inverse game theory: infer payoffs from observed equilibrium play
int test_inverse_game_theory() {
    std::cout << "~~~ inverse game theory: infer payoff from observed play ~~~" << std::endl;

    // NOTE: O = nfg_profile_t must match the program's return type
    pp_t<std::optional<nfg_profile_t>, nfg_profile_t, Normal, NormalFormGame> f = coordination_model;
    auto q = weighted_mean<nfg_profile_t, Normal, NormalFormGame>("gain");
    auto opts = inf_options_t(2000);
    auto infer = inference<LikelihoodWeighting>(f, *q, opts);

    // named lvalues: operator()(I&) requires an addressable, non-temporary input
    std::optional<nfg_profile_t> stag_data = nfg_profile_t {0ul, 0ul};
    std::optional<nfg_profile_t> hare_data = nfg_profile_t {1ul, 1ul};

    auto play_stag = infer(stag_data);
    std::cout << "E[gain | play = (0, 0)] = " << play_stag << " (prior mean 2.0)" << std::endl;

    auto play_hare = infer(hare_data);
    std::cout << "E[gain | play = (1, 1)] = " << play_hare << " (prior mean 2.0)" << std::endl;

    if (!(play_stag > 2.0 && play_hare < 2.0 && play_stag > play_hare)) return 1;
    return 0;
}

// record-level semantics: inspect and replay through a game node
int test_record_semantics() {
    std::cout << "~~~ game nodes in records ~~~" << std::endl;

    record_t<DTypes<Normal, NormalFormGame>> r;
    auto ret = coordination_model(r, std::nullopt);   // ret is now nfg_profile_t; indexing valid
    std::cout << "prior predictive play = (" << ret[0] << ", " << ret[1] << ")\n";
    std::cout << display(r) << std::endl;

    auto& node = std::get<node_t<NormalFormGame>>(r.map["play"]);
    std::cout << "solved QRE: " << node.distribution.string() << std::endl;

    std::cout << "logprob(record) = " << logprob(r) << std::endl;
    std::cout << "loglikelihood(record) = " << loglikelihood(r) << std::endl;

    return 0;
}

// ---------------------------------------------------------------------------
// Independent residual check: given the SOLVED sigma, recompute the quantal
// response from scratch and confirm it reproduces sigma. This validates the
// solver against its defining equations, not against memorized answers.
// ---------------------------------------------------------------------------
double qre_residual(const NormalFormGame& g) {
    const auto& u_row = g.u_row;
    const auto& u_col = g.u_col;
    double worst = 0.0;

    std::vector<double> eu_row(g.sigma_row.size()), qr_row(g.sigma_row.size());
    for (size_t a = 0; a != g.sigma_row.size(); ++a) {
        double e = 0.0;
        for (size_t b = 0; b != g.sigma_col.size(); ++b) e += g.sigma_col[b] * u_row[a][b];
        eu_row[a] = e;
    }
    double mx = *std::max_element(eu_row.begin(), eu_row.end());
    double Z = 0.0;
    for (size_t a = 0; a != eu_row.size(); ++a) { qr_row[a] = std::exp(g.lambda * (eu_row[a] - mx)); Z += qr_row[a]; }
    for (auto& v : qr_row) v /= Z;
    for (size_t a = 0; a != qr_row.size(); ++a) worst = std::max(worst, std::fabs(qr_row[a] - g.sigma_row[a]));

    std::vector<double> eu_col(g.sigma_col.size()), qr_col(g.sigma_col.size());
    for (size_t b = 0; b != g.sigma_col.size(); ++b) {
        double e = 0.0;
        for (size_t a = 0; a != g.sigma_row.size(); ++a) e += g.sigma_row[a] * u_col[a][b];
        eu_col[b] = e;
    }
    mx = *std::max_element(eu_col.begin(), eu_col.end());
    Z = 0.0;
    for (size_t b = 0; b != eu_col.size(); ++b) { qr_col[b] = std::exp(g.lambda * (eu_col[b] - mx)); Z += qr_col[b]; }
    for (auto& v : qr_col) v /= Z;
    for (size_t b = 0; b != qr_col.size(); ++b) worst = std::max(worst, std::fabs(qr_col[b] - g.sigma_col[b]));

    return worst;
}

int test_asymmetric_zero_sum() {
    std::cout << "~~~ asymmetric zero-sum: unique interior mixed NE ~~~" << std::endl;

    // ordinary payoffs; NE: row plays action 0 w.p. 1/3, col w.p. 4/9, value 1/3
    std::vector<std::vector<double>> u_row = { {2.0, -1.0}, {-0.5, 1.0} };
    std::vector<std::vector<double>> u_col = { {-2.0, 1.0}, {0.5, -1.0} };

    const double p_star = 1.0 / 3.0;   // row's NE mixture over action 0
    const double q_star = 4.0 / 9.0;   // col's NE mixture over action 0
    const double v_star = 1.0 / 3.0;   // value of the game to row

    // analytic derivation printed for transparency when debugging
    std::cout << "game: u_row = [[2, -1], [-0.5, 1]], zero-sum (u_col = -u_row)"
              << std::endl;
    std::cout << "analytic mixed NE: p0* = " << p_star
              << " (from col indifference: 2q - 0.5(1-q) = -q + (1-q))"
              << std::endl;
    std::cout << "                    q0* = " << q_star
              << " (from row indifference: 2p - (1-p) = -0.5p + (1-p))"
              << std::endl;
    std::cout << "game value to row: v* = " << v_star << std::endl;

    // --- solve at lambda = 4 ---
    auto g4 = NormalFormGame(u_row, u_col, 4.0);
    CHECK(g4.converged, [&]{
        std::cout << "fixed-point iteration did NOT converge at lambda=4 "
                  << "after " << g4.max_iter << " iterations "
                  << "(tolerance " << g4.tolerance << "). "
                  << "This indicates the damped iteration is oscillating or "
                  << "diverging; suspect damping/solver logic, not the game.";
    });

    double err_p4 = std::fabs(g4.action_probs(0)[0] - p_star);
    double err_q4 = std::fabs(g4.action_probs(1)[0] - q_star);
    std::cout << "lambda=4:  p0=" << g4.action_probs(0)[0] << " (want " << p_star
              << "), q0=" << g4.action_probs(1)[0] << " (want " << q_star << ")"
              << ", E[payoff] = " << g4.expected_payoff(0) << std::endl;

    // --- solve at lambda = 8 ---
    auto g8 = NormalFormGame(u_row, u_col, 8.0);
    CHECK(g8.converged, [&]{
        std::cout << "fixed-point iteration did NOT converge at lambda=8 "
                  << "after " << g8.max_iter << " iterations "
                  << "(tolerance " << g8.tolerance << "). "
                  << "Zero-sum games have near-unit-modulus Jacobian eigenvalues "
                  << "of the response map at high lambda (slow contraction, "
                  << "rate ~ 1 - c/lambda); if this fires repeatedly, consider "
                  << "raising max_iter or adding oscillation-adaptive damping. "
                  << "Last iterates: sigma_row=[" << g8.action_probs(0)[0] << ", "
                  << g8.action_probs(0)[1] << "] sigma_col=[" << g8.action_probs(1)[0]
                  << ", " << g8.action_probs(1)[1] << "]";
    });

    double err_p8 = std::fabs(g8.action_probs(0)[0] - p_star);
    double err_q8 = std::fabs(g8.action_probs(1)[0] - q_star);
    std::cout << "lambda=8: p0=" << g8.action_probs(0)[0] << " (want " << p_star
              << "), q0=" << g8.action_probs(1)[0] << " (want " << q_star << ")"
              << ", E[payoff] = " << g8.expected_payoff(0)
              << " (want " << v_star << ")" << std::endl;

    // --- checks with specific failure diagnostics ---

    // 1. moderate-precision QRE is near (but not exactly at) the NE
    CHECK(err_p4 <= 0.08, [&]{
        std::cout << "lambda=4 QRE row mixture off by " << err_p4
                  << " (> 0.08). Got p0=" << g4.action_probs(0)[0]
                  << ", expected approx " << p_star
                  << " (finite-lambda QRE sits near the mixed NE). "
                  << "Large deviation suggests wrong NE, wrong sign of lambda, "
                  << "or a transpose error in u_col indexing.";
    });
    CHECK(err_q4 <= 0.08, [&]{
        std::cout << "lambda=4 QRE col mixture off by " << err_q4
                  << " (> 0.08). Got q0=" << g4.action_probs(1)[0]
                  << ", expected approx " << q_star
                  << " (finite-lambda QRE sits near the mixed NE). "
                  << "Note the mixtures are ASYMMETRIC (1/3 vs 4/9) -- if both "
                  << "came out equal, suspect player-role symmetry bugs.";
    });

    std::cout << "  all checks passed." << std::endl;
    return 0;
}

// ---------------------------------------------------------------------------
// Game 2: iterated strict dominance, 3x3, unique pure NE at (0, 0).
//
//   u_row = [[4, 4, 2],     row 2 strictly dominated by row 0 (4>3, 4>3, 2>1)
//            [1, 0, 0],
//            [3, 3, 1]]
//
//   u_col = [[3, 0, 1],     after deleting row 2, col 2 strictly dominated by
//            [2, 1, 0]]     col 0 (3>1, 2>0); then in the remaining 2x2,
//                            row 0 dominates row 1 (4>1, 4>0) and col 0
//                            dominates col 1 (3>0, 2>1).
//
// Unique NE = (0, 0). Exercises 3x3 solve + rectangular support pruning,
// and the QRE at moderate lambda must put decisive mass on (0,0).
// ---------------------------------------------------------------------------
int test_iterated_dominance() {
    std::cout << "~~~ 3x3 iterated strict dominance: unique pure NE (0,0) ~~~" << std::endl;

    std::vector<std::vector<double>> u_row = {
        {4.0, 4.0, 2.0},
        {1.0, 0.0, 0.0},
        {3.0, 3.0, 1.0}
    };
    std::vector<std::vector<double>> u_col = {
        {3.0, 0.0, 1.0},
        {2.0, 1.0, 0.0},
        {2.0, 0.0, 1.0}   // chosen so col0 > col2 on rows 0,1; arbitrary elsewhere
    };

    auto g = NormalFormGame(u_row, u_col, 8.0);
    if (!g.converged) return 1;
    std::cout << g.string() << std::endl;

    // dominance cascade => decisively (0, 0)
    if (g.action_probs(0)[0] < 0.9 || g.action_probs(1)[0] < 0.9) return 1;

    // independently: given col concentrates near col0 (prob pr0),
    // row's best response ordering must be row0 > row2 > row1
    double pr0 = g.action_probs(1)[0];
    std::vector<double> eu(3);
    for (size_t a = 0; a != 3; ++a) eu[a] = pr0 * u_row[a][0] + (1.0 - pr0) * u_row[a][1];
    if (!((eu[0] > eu[2] ) && (eu[2] > eu[1]))) return 1;

    return 0;
}

// ---------------------------------------------------------------------------
// Game 3: battle of the sexes -- asymmetric COORDINATION game (two pure NE +
// one mixed NE at p_row(opera) = 3/4, q_col(opera) = 1/4). Tests the solver
// where multiple equilibria exist and payoffs are strongly asymmetric across
// players. We assert the definitional property (fixed-point residual) plus
// mutual-best-response structure of modal actions, NOT which equilibrium
// the principal branch selects (that is a modeling choice, already covered
// by the stag hunt test).
// ---------------------------------------------------------------------------
int test_battle_of_the_sexes() {
    std::cout << "~~~ battle of the sexes: asymmetric coordination ~~~" << std::endl;

    // 0 = opera, 1 = football; row prefers opera, col prefers football
    std::vector<std::vector<double>> u_row = { {3.0, 0.0}, {0.0, 1.0} };
    std::vector<std::vector<double>> u_col = { {1.0, 0.0}, {0.0, 3.0} };

    for (double lam : {0.5, 1.0, 3.0, 5.0, 10.0}) {
        auto g = NormalFormGame(u_row, u_col, lam);
        if (!g.converged) return 1;
        double resid = qre_residual(g);
        std::cout << "lambda=" << lam << ": sigma_row=[" << g.action_probs(0)[0]
                  << ", " << g.action_probs(0)[1] << "] sigma_col=["
                  << g.action_probs(1)[0] << ", " << g.action_probs(1)[1]
                  << "] residual=" << resid << std::endl;

        // modal actions must be mutual best responses to each other's mixture
        size_t a_mode = g.action_probs(0)[0] >= g.action_probs(0)[1] ? 0 : 1;
        size_t b_mode = g.action_probs(1)[0] >= g.action_probs(1)[1] ? 0 : 1;
        double row_eu_a = 0.0, row_eu_alt = 0.0, col_eu_b = 0.0, col_eu_alt = 0.0;
        for (size_t b = 0; b != 2; ++b) {
            row_eu_a += g.action_probs(1)[b] * u_row[a_mode][b];
            row_eu_alt += g.action_probs(1)[b] * u_row[1 - a_mode][b];
        }
        for (size_t a = 0; a != 2; ++a) {
            col_eu_b += g.action_probs(0)[a] * u_col[a][b_mode];
            col_eu_alt += g.action_probs(0)[a] * u_col[a][1 - b_mode];
        }
        if (row_eu_a < row_eu_alt || col_eu_b < col_eu_alt) return 1;
    }

    // transpose-swap invariance: swapping the players' roles must swap the
    // solutions exactly (strong check on asymmetric bookkeeping)
    auto g = NormalFormGame(u_row, u_col, 3.0);
    auto g_sw = NormalFormGame(u_col, u_row, 3.0);
    for (size_t a = 0; a != 2; ++a) {
        if (std::fabs(g.action_probs(0)[a] - g_sw.action_probs(1)[a]) > 1e-12) return 1;
        if (std::fabs(g.action_probs(1)[a] - g_sw.action_probs(0)[a]) > 1e-12) return 1;
    }

    return 0;
}

// ---------------------------------------------------------------------------
// Game 4: randomized stress test -- random payoff matrices (including negative
// entries and badly scaled payoffs), then verify (a) convergence flags and
// (b) fixed-point residuals. No expected answer needed; the defining
// equations ARE the oracle.
// ---------------------------------------------------------------------------
int test_random_games() {
    std::cout << "~~~ randomized games: residual stress test ~~~" << std::endl;

    std::uniform_real_distribution<double> pay(-50.0, 50.0);
    std::uniform_real_distribution<double> lam_dist(0.1, 10.0);

    for (size_t trial = 0; trial != 200; ++trial) {
        size_t m = 2 + (trial % 4);   // sizes 2..5
        size_t n = 2 + ((trial * 7) % 4);
        std::vector<std::vector<double>> ur(m, std::vector<double>(n)), uc(m, std::vector<double>(n));
        for (size_t a = 0; a != m; ++a)
            for (size_t b = 0; b != n; ++b) { ur[a][b] = pay(rng); uc[a][b] = pay(rng); }

        auto g = NormalFormGame(ur, uc, lam_dist(rng));
        double resid = qre_residual(g);

        if (!g.converged) {
            std::cout << "  trial " << trial << ": did NOT converge, residual = " << resid << std::endl;
            std::cout << g.string() << std::endl;
            // non-convergence at extreme lambda on adversarial random games is
            // survivable, but residual must still be reported; flag only if bad
        }
        if (resid > 1e-2) {
            std::cout << "  trial " << trial << ": residual is large = " << resid << std::endl;
        }
    }
    return 0;
}

/* dynamic game stuff below */

void expect(const char* cond, bool ok) {
    if (ok) { printf("[PASS] %s\n", cond); return; }
    printf("[FAIL] %s\n", cond);
}

bool path_is(const std::vector<std::pair<int, std::string>>& got,
             const std::vector<std::pair<int, std::string>>& want) {
    return got == want;
}

int test_basic_dynamic_game() {
    std::cout << "--- Dynamic game #1: almost as simple as it gets ---" << std::endl;
    auto tree = Node::decision(0, {"Out", "In"},
        {
            Node::terminal_node({2, 2}),
            Node::decision(1, {"L", "R"},
                {
                    Node::terminal_node({0, 5}),
                    Node::terminal_node({4, 4}),
                })
        });

    std::vector<std::string> path;
    auto payoffs = solve(tree, &path);

    std::cout << "Equilibrium path: " << std::endl;
    for (auto& a : path) printf("  %s\n", a.c_str());
    printf("Payoffs:");
    for (double p : payoffs) printf(" %.1f", p);
    printf("\n");
    return 0;
}

int test_deeper_dynamic_game() {
    std::cout << "--- Dynamic game #2: slightly deeper ---" << std::endl;
    // P0: take -> (4,1), pass -> P1: take -> (2,6), pass -> P0: take -> (8,3), pass -> (0,9)
    auto leaf_pass = Node::terminal_node({0, 9});
    auto deep = Node::decision(0, {"take", "pass"},
        {Node::terminal_node({8, 3}), leaf_pass});
    auto mid = Node::decision(1, {"take", "pass"},
        {Node::terminal_node({2, 6}), deep});
    auto tree = Node::decision(0, {"take", "pass"},
        {Node::terminal_node({4, 1}), mid});

    std::vector<std::string> path;
    auto payoffs = solve(tree, &path);

    print_tree(tree);

    std::cout << "Equilibrium path: " << std::endl;
    for (auto& a : path) printf("  %s\n", a.c_str());
    printf("Payoffs:");
    for (double p : payoffs) printf(" %.1f", p);
    printf("\n");
    return 0;
}

int test_three_player_dynamic_game() {
    std::cout << "--- Dynamic game #3: three players now ---" << std::endl;
    // P2 picks between (10,10,1) and (2,2,3) -> picks second (3>1).
    // P1 anticipates: between (10,10,1-path->(2,2,3)) hmm — build:
    // P0 roots: "share" -> P1 node; "grab" -> (5,5,0)
    // P1: "share2" -> P2 node; "grab2" -> (0,9,2)
    // P2: "final_a" -> (6,6,1); "final_b" -> (2,2,3)
    auto p2 = Node::decision(2, {"fa", "fb"},
        {Node::terminal_node({6, 6, 1}), Node::terminal_node({2, 2, 3})});
    auto p1 = Node::decision(1, {"s2", "g2"},
        {p2, Node::terminal_node({0, 9, 2})});
    auto tree = Node::decision(0, {"s1", "g1"},
        {p1, Node::terminal_node({5, 5, 0})});

    std::vector<std::string> path;
    auto payoffs = solve(tree, &path);

    print_tree(tree);

    std::cout << "Equilibrium path: " << std::endl;
    auto equlibrium = eq_path(tree);

    for (auto& a : equlibrium) {
        std::cout << a.first << " -> " << a.second << std::endl;
    }
    printf("Payoffs:");
    for (double p : payoffs) printf(" %.1f", p);
    printf("\n");
    return 0;
}

int test_eq_is_deep_in_tree() {
    std::cout << "--- Dynamic game #4: the eq deep in the tree ---" << std::endl;
    auto bottom = Node::decision(0, {"Stop", "Continue"},
        {Node::terminal_node({3, 2}), Node::terminal_node({4, 3})});
    auto middle = Node::decision(1, {"Left", "Right"},
        {Node::terminal_node({2, 1}), bottom});
    auto tree = Node::decision(0, {"Out", "In"},
        {Node::terminal_node({1, 2}), middle});

    std::vector<std::string> path;
    auto payoffs = solve(tree, &path);

    print_tree(tree);

    std::cout << "Equilibrium path: " << std::endl;
    auto equlibrium = eq_path(tree);

    for (auto& a : equlibrium) {
        std::cout << a.first << " -> " << a.second << std::endl;
    }
    printf("Payoffs:");
    for (double p : payoffs) printf(" %.1f", p);
    printf("\n");
    return 0;
}

int test_symmetric_coordination() {
    std::cout << "--- Dynamic game #5: a symmetric coordination game ---" << std::endl;
    auto left  = Node::decision(1, {"A", "B"},
        {Node::terminal_node({2, 2}), Node::terminal_node({0, 0})});
    auto right = Node::decision(1, {"A", "B"},
        {Node::terminal_node({0, 0}), Node::terminal_node({2, 2})});
    auto tree = Node::decision(0, {"A", "B"}, {left, right});

    // Root is a genuine tie: both branches yield (2,2). Tie-break -> "A".
    expect("T-S1 coordination path is P0:A, P1:A",
           path_is(eq_path(tree), {{0, "A"}, {1, "A"}}));

    print_tree(tree);
    std::vector<std::string> path;
    auto payoffs = solve(tree, &path);

    std::cout << "Equilibrium path: " << std::endl;
    auto equlibrium = eq_path(tree);

    for (auto& a : equlibrium) {
        std::cout << a.first << " -> " << a.second << std::endl;
    }
    printf("Payoffs:");
    for (double p : payoffs) printf(" %.1f", p);
    printf("\n");

    // The two subtrees are mirrors: P1's eq_choice must be 0 on the left
    // and 1 on the right -- same value function, opposite action.
    expect("T-S1 mirrored subtrees choose mirrored actions",
           left->eq_choice == 0 && right->eq_choice == 1);

    // Label-consistent mirror: swap children AND their labels together.
    // Now following index 0 means playing "B", and the path is (B, B).
    auto tree_m = Node::decision(0, {"B", "A"}, {right, left});
    expect("T-S1 label-consistent mirror path is P0:B, P1:B",
        path_is(eq_path(tree_m), {{0, "B"}, {1, "B"}}));
    
    print_tree(tree_m);
    std::vector<std::string> path2;
    auto payoffs2 = solve(tree_m, &path2);

    std::cout << "Equilibrium path: " << std::endl;
    auto equlibrium2 = eq_path(tree_m);

    for (auto& a : equlibrium2) {
        std::cout << a.first << " -> " << a.second << std::endl;
    }
    printf("Payoffs:");
    for (double p : payoffs2) printf(" %.1f", p);
    printf("\n");

    return 0;
}

// T-S3: Sequential matching pennies. Same symmetric tree shape as T-S1,
// but payoffs make the interests opposed: P0 wants a match, P1 wants to
// mismatch. The tree is symmetric, yet the equilibrium is one-sided --
// P1 (moving second) always wins the mismatch. Demonstrates that a
// symmetric structure imposes no symmetry on the outcome.
int test_symmetric_structure_asymmetric_outcome() {
    std::cout << "--- Dynamic game #6: a symmetric coordination game with asymmetric payouts ---" << std::endl;
    // Under either P0 action, P1 mismatches: mismatch gives P1 +1 vs match -1.
    auto respond = [] {
        return Node::decision(1, {"match", "mismatch"},
            {Node::terminal_node({2, -1}), Node::terminal_node({-1, 1})});
    };
    auto left  = respond();
    auto right = respond();
    auto tree = Node::decision(0, {"Heads", "Tails"}, {left, right});

    expect("T-S3 second mover always mismatches -> P0 loses",
           path_is(eq_path(tree), {{0, "Heads"}, {1, "mismatch"}}));

    print_tree(tree);
    std::vector<std::string> path;
    auto payoffs = solve(tree, &path);

    std::cout << "Equilibrium path: " << std::endl;
    auto equlibrium = eq_path(tree);

    for (auto& a : equlibrium) {
        std::cout << a.first << " -> " << a.second << std::endl;
    }
    printf("Payoffs:");
    for (double p : payoffs) printf(" %.1f", p);
    printf("\n");

    // P1's strategy is unconditional mismatch in BOTH subgames, unlike
    // the coordination case where the choice depended on the branch.
    expect("T-S3 P1 mismatches in every subgame (strategy is uniform)",
           left->eq_choice == 1 && right->eq_choice == 1);

    return 0;
}

template<bool Print>
double profit_model(
    record_t<DTypes<Gamma, Normal, DynamicGame>>& r,
    dynamic_play_t observed_play
) {
    auto prod_high = sample(r, "prod/high", Gamma(2.0, 1.0), rng);
    auto prod_low = sample(r, "prod/low", Gamma(2.0, 1.0), rng);
    auto gov_lots = sample(r, "gov/lots", Normal(0.0, 1.0), rng);
    auto gov_little = sample(r, "gov/little", Normal(0.0, 1.0), rng);
    auto game = Node::decision(
        0, {"high", "low"}, {
            Node::decision(
                1, {"lots", "little"}, {
                    Node::terminal_node({prod_high, 1.0 - gov_lots}),
                    Node::terminal_node({prod_high * 0.75, 0.25 - gov_little})
                }
            ),
            Node::decision(
                1, {"lots", "little"}, {
                    Node::terminal_node({prod_low * 0.25, 0.75 - gov_lots}),
                    Node::terminal_node({prod_low * 1.25, 1.25 - gov_little})
                }
            )
        }
    );
    if constexpr (Print) print_tree(game);
    observe(r, "decision", DynamicGame(game), observed_play);
    return (prod_high + prod_low) / 2.0;
}

int test_basic_program_dynamic() {
    std::cout << "--- Dynamic game #7: tracing a dynamic game inside a prob program ---" << std::endl;

    record_t<DTypes<Gamma, Normal, DynamicGame>> r;
    dynamic_play_t observed_play = {{0, "low"}, {1, "little"}};
    auto prod = profit_model<true>(r, observed_play);
    std::cout << "Recorded sites in a prob prog with an internally defined dynamic game" << std::endl;
    std::cout << display(r) << std::endl;

    dynamic_play_t observed_play_2 = {{0, "high"}, {1, "little"}};
    prod = profit_model<true>(r, observed_play_2);
    std::cout << "Changed observations..." << std::endl;
    std::cout << display(r) << std::endl;

    // now do actual inference
    pp_t<dynamic_play_t, double, Gamma, Normal, DynamicGame> f = profit_model<true>;
    auto q = weighted_record<double, Gamma, Normal, DynamicGame>();
    auto opts = inf_options_t(3);
    auto infer = inference<LikelihoodWeighting>(f, *q, opts);
    auto results = infer(observed_play);
    for (auto& rec : results->_v) {
        std::cout << display(rec) << std::endl;
    }

    // with real sampling
    f = profit_model<false>;
    // this is just to show We Can Do It -- the actual posterior will be 
    // egregiouisly multimodal (since, in non-probabilistic treatment -- just consider as 
    // linear algebra -- the problem is underconstrained with four parameters for a two-move,
    // two-player game)
    auto q2 = ProductGenerator<WeightedMean, double, double, Gamma, Normal, DynamicGame>::generate(
        {"prod/high", "prod/low", "gov/lots", "gov/little"}
    );
    auto opts2 = inf_options_t(1000);
    auto infer2 = inference<LikelihoodWeighting>(f, q2, opts2);
    auto results2 = infer2(observed_play);
    for (const auto& [k, v] : results2.values) {
        std::cout << "E[" << k << " | gameplay] = " << v << std::endl;
    }

    return 0;
}

int main(int argc, char ** argv) {
    auto status = std::vector<int>({
        test_prisoners_dilemma(),
        test_matching_pennies(),
        test_stag_hunt(),
        test_sampling_consistency(),
        test_record_semantics(),
        test_inverse_game_theory(),
        test_asymmetric_zero_sum(),
        test_iterated_dominance(),
        test_battle_of_the_sexes(),
        test_random_games(),
        test_basic_dynamic_game(),
        test_deeper_dynamic_game(),
        test_three_player_dynamic_game(),
        test_eq_is_deep_in_tree(),
        test_symmetric_coordination(),
        test_symmetric_structure_asymmetric_outcome(),
        test_basic_program_dynamic()
    });
    if (*std::max_element(status.begin(), status.end()) > 0) {
        std::cout << "~~~ Test failed; read log for more. ~~~\n";
        return 1;
    } else {
        std::cout << "~~~ All tests passed. ~~~\n";
        return 0;
    }
}