/** @file
 * This file is part of fmcs.
 * Copyright David Rushing Dewhurst, 2026 - present.
 * Some rights reserved.
 *
 * @brief Game-theoretic distributions. The solved game is represented as a
 * distribution over joint pure action profiles; the equilibrium selection
 * rule is the logit quantal response equilibrium (QRE).
 */

#ifndef GAME_DISTRIBUTIONS_H
#define GAME_DISTRIBUTIONS_H

#include <algorithm>
#include <array>
#include <cmath>
#include <limits>
#include <memory>
#include <random>
#include <sstream>
#include <string>
#include <tuple>
#include <utility>
#include <vector>

#include <distributions.hpp>
#include <distribution_traits.hpp>
#include <domains.hpp>

/**
 * @brief Value type of a two-player normal form game node: the joint pure
 * action profile. value[0] = row player's action index, value[1] = column
 * player's action index.
 */
using nfg_profile_t = std::array<unsigned long, 2>;

namespace nfg_detail {

    /**
     * @brief Stabilized softmax: out[a] = exp(lam * (u[a] - max u)) / Z.
     * Max-shift prevents overflow at high precision.
     */
    inline void softmax(double lam, const std::vector<double>& u, std::vector<double>& out) {
        double mx = *std::max_element(u.begin(), u.end());
        double Z = 0.0;
        for (size_t a = 0; a != u.size(); ++a) {
            out[a] = std::exp(lam * (u[a] - mx));
            Z += out[a];
        }
        for (auto& v : out) v /= Z;
    }

    inline double supnorm_diff(const std::vector<double>& x, const std::vector<double>& y) {
        double d = 0.0;
        for (size_t i = 0; i != x.size(); ++i) d = std::max(d, std::fabs(x[i] - y[i]));
        return d;
    }

}  // namespace nfg_detail

/**
 * @brief A two-player normal form game with QRE equilibrium selection.
 *
 * Solves the logit-QRE fixed point on construction:
 *
 *   sigma_row(a) prop exp(lambda * E_{b ~ sigma_col}[ u_row(a, b) ])
 *   sigma_col(b) prop exp(lambda * E_{a ~ sigma_row}[ u_col(a, b) ])
 *
 * The node value is a joint pure action profile drawn from
 * p(a, b) = sigma_row(a) * sigma_col(b), so:
 *
 *   logprob((a, b)) = log sigma_row(a) + log sigma_col(b)
 *
 * Special cases of the selection rule:
 *   - lambda = 0   : uniform over joint actions (maximum entropy)
 *   - lambda -> infty : Nash equilibrium selection (the QRE branch traced
 *     from the uniform distribution converges to a selected NE -- for
 *     generic games, the risk-dominant one)
 *
 * Unlike exact-NE selection, the QRE map is a smooth function of the payoff
 * matrices, so likelihood-weighting and Metropolis inference over upstream
 * payoff nodes behaves well (no piecewise-constant likelihoods).
 */
struct NormalFormGame : Distribution<NormalFormGame, nfg_profile_t> {

    /// u_row[a][b]: row player's payoff from joint action (a, b)
    std::vector<std::vector<double>> u_row;
    /// u_col[a][b]: column player's payoff from joint action (a, b)
    std::vector<std::vector<double>> u_col;

    double lambda;      ///< QRE precision (1/temperature)
    double damping;     ///< fixed-point iteration damping factor in (0, 1]
    double tolerance;
    size_t max_iter;
    bool converged;     ///< false if the fixed-point iteration hit max_iter

    /// solved QRE mixed strategies
    std::vector<double> sigma_row;
    std::vector<double> sigma_col;

    NormalFormGame(std::vector<std::vector<double>> u_row_,
                   std::vector<std::vector<double>> u_col_,
                   double lambda_ = 1.0,
                   double damping_ = 0.5,
                   double tolerance_ = 1e-2,
                   size_t max_iter_ = 50000)
        : u_row(std::move(u_row_)),
          u_col(std::move(u_col_)),
          lambda(lambda_),
          damping(damping_),
          tolerance(tolerance_),
          max_iter(max_iter_),
          converged(true) {
        solve();
    }

    template<typename... Vs>
    NormalFormGame(std::variant<Vs...> u_row,
                   std::variant<Vs...> u_col,
                   std::variant<Vs...> lambda)
        : NormalFormGame(
            std::get<std::vector<std::vector<double>>>(u_row),
            std::get<std::vector<std::vector<double>>>(u_col),
            std::get<double>(lambda)
        ) {}

    /**
     * @brief Solve the QRE fixed point. Uses lambda-continuation: starts at
     * lam = min(lambda, 1) where the softmax response map is close to a
     * contraction, then doubles lam up to the target, warm-starting each
     * rung. This traces the principal QRE branch toward the NE as
     * lambda grows, and markedly improves convergence at high precision.
     */
    void solve() {
        const size_t m = u_row.size();
        const size_t n = u_col[0].size();
        sigma_row.assign(m, 1.0 / static_cast<double>(m));
        sigma_col.assign(n, 1.0 / static_cast<double>(n));
        converged = true;
        double lam = std::min(lambda, 1.0);
        while (true) {
            if (!_fixed_point(lam)) converged = false;
            if (lam >= lambda) break;
            lam = std::min(lambda, lam * 2.0);
        }
    }

private:

    bool _fixed_point(double lam) {
        const size_t m = sigma_row.size();
        const size_t n = sigma_col.size();
        
        // Proximal QRE iteration (contraction mapping for all lambda)
        // Update rule: sigma_new = argmax_sigma { E_u(sigma) - (1/lambda)*H(sigma) - (mu/2)||sigma - sigma_old||^2 }
        // This adds regularization that guarantees convergence at the cost of slower progress
        
        double mu = 0.01;  // proximal parameter; controls step size
        double eta = 0.1;  // initial mixing weight
        
        std::vector<double> eu_row(m), eu_col(n);
        std::vector<double> qr_row(m), qr_col(n);
        
        for (size_t it = 0; it != max_iter; ++it) {
            // Compute expected utilities against current sigma
            for (size_t a = 0; a != m; ++a) {
                double e = 0.0;
                for (size_t b = 0; b != n; ++b) e += sigma_col[b] * u_row[a][b];
                eu_row[a] = e;
            }
            for (size_t b = 0; b != n; ++b) {
                double e = 0.0;
                for (size_t a = 0; a != m; ++a) e += sigma_row[a] * u_col[a][b];
                eu_col[b] = e;
            }
            
            // Softmax with regularization (effective lambda is reduced by proximal term)
            // We solve: maximize lambda*u - entropy - mu*(sigma - prev)^2
            // This yields: softmax((lambda*u + mu*prev)/(1+mu))
            std::vector<double> eff_row(m), eff_col(n);
            for (size_t a = 0; a != m; ++a) eff_row[a] = (lam * eu_row[a] + mu * sigma_row[a]) / (1.0 + mu);
            for (size_t b = 0; b != n; ++b) eff_col[b] = (lam * eu_col[b] + mu * sigma_col[b]) / (1.0 + mu);
            
            // Stabilized softmax
            {
                double mx = *std::max_element(eff_row.begin(), eff_row.end());
                double Z = 0.0;
                for (size_t a = 0; a != m; ++a) qr_row[a] = std::exp(eff_row[a] - mx), Z += qr_row[a];
                for (auto& v : qr_row) v /= Z;
            }
            {
                double mx = *std::max_element(eff_col.begin(), eff_col.end());
                double Z = 0.0;
                for (size_t b = 0; b != n; ++b) qr_col[b] = std::exp(eff_col[b] - mx), Z += qr_col[b];
                for (auto& v : qr_col) v /= Z;
            }
            
            // Proximal update (convex combination)
            for (size_t a = 0; a != m; ++a)
                sigma_row[a] = eta * qr_row[a] + (1.0 - eta) * sigma_row[a];
            for (size_t b = 0; b != n; ++b)
                sigma_col[b] = eta * qr_col[b] + (1.0 - eta) * sigma_col[b];
            
            // Convergence check: sup-norm of update
            double d = 0.0;
            for (size_t a = 0; a != m; ++a) d = std::max(d, std::fabs(qr_row[a] - sigma_row[a]));
            for (size_t b = 0; b != n; ++b) d = std::max(d, std::fabs(qr_col[b] - sigma_col[b]));
            
            if (d < tolerance) { converged = true; return true; }
            
            // Adaptive damping: if progress stalls, reduce eta; if oscillation detected, cut eta
            // Simple heuristic: every 50 iterations check if d increased from last check
            static size_t last_check = 0;
            static double last_d = INFINITY;
            if (it - last_check >= 50) {
                if (d > last_d * 0.99) eta *= 0.7;  // stall: reduce step
                else eta = std::min(eta * 1.1, 0.5);  // progress: increase step
                eta = std::max(eta, 1e-6);
                last_d = d;
                last_check = it + 1;
            }
        }
        
        // If we didn't converge within max_iter, try one more pass with ultra-small eta
        // This is the "desperate" mode for pathological games
        if (!converged) {
            eta = 1e-4;
            mu = 0.05;
            for (size_t it = 0; it != max_iter; ++it) {
                // Recompute eu, eff, qr as above...
                // (Same code block repeated for clarity; would factorize in production)
                for (size_t a = 0; a != m; ++a) {
                    double e = 0.0;
                    for (size_t b = 0; b != n; ++b) e += sigma_col[b] * u_row[a][b];
                    eu_row[a] = e;
                }
                for (size_t b = 0; b != n; ++b) {
                    double e = 0.0;
                    for (size_t a = 0; a != m; ++a) e += sigma_row[a] * u_col[a][b];
                    eu_col[b] = e;
                }
                std::vector<double> eff_row(m), eff_col(n);
                for (size_t a = 0; a != m; ++a) eff_row[a] = (lam * eu_row[a] + mu * sigma_row[a]) / (1.0 + mu);
                for (size_t b = 0; b != n; ++b) eff_col[b] = (lam * eu_col[b] + mu * sigma_col[b]) / (1.0 + mu);
                {
                    double mx = *std::max_element(eff_row.begin(), eff_row.end());
                    double Z = 0.0;
                    for (size_t a = 0; a != m; ++a) qr_row[a] = std::exp(eff_row[a] - mx), Z += qr_row[a];
                    for (auto& v : qr_row) v /= Z;
                }
                {
                    double mx = *std::max_element(eff_col.begin(), eff_col.end());
                    double Z = 0.0;
                    for (size_t b = 0; b != n; ++b) qr_col[b] = std::exp(eff_col[b] - mx), Z += qr_col[b];
                    for (auto& v : qr_col) v /= Z;
                }
                for (size_t a = 0; a != m; ++a)
                    sigma_row[a] = eta * qr_row[a] + (1.0 - eta) * sigma_row[a];
                for (size_t b = 0; b != n; ++b)
                    sigma_col[b] = eta * qr_col[b] + (1.0 - eta) * sigma_col[b];
                
                double d = 0.0;
                for (size_t a = 0; a != m; ++a) d = std::max(d, std::fabs(qr_row[a] - sigma_row[a]));
                for (size_t b = 0; b != n; ++b) d = std::max(d, std::fabs(qr_col[b] - sigma_col[b]));
                
                if (d < tolerance) { converged = true; return true; }
            }
        }
        
        converged = false;
        return false;
    }

public:

    /// @brief Number of actions for player 0 (row) or 1 (column)
    size_t n_actions(size_t player) const {
        return player == 0 ? sigma_row.size() : sigma_col.size();
    }

    /// @brief The solved QRE mixed strategy for the requested player
    const std::vector<double>& action_probs(size_t player) const {
        return player == 0 ? sigma_row : sigma_col;
    }

    /// @brief Ex ante expected QRE payoff for the requested player
    double expected_payoff(size_t player) const {
        double e = 0.0;
        for (size_t a = 0; a != sigma_row.size(); ++a) {
            for (size_t b = 0; b != sigma_col.size(); ++b) {
                e += sigma_row[a] * sigma_col[b] * (player == 0 ? u_row[a][b] : u_col[a][b]);
            }
        }
        return e;
    }

    template<typename RNG>
    nfg_profile_t sample(RNG& rng) {
        std::discrete_distribution<unsigned long> dist_row(
            sigma_row.begin(), sigma_row.end()
        );
        std::discrete_distribution<unsigned long> dist_col(
            sigma_col.begin(), sigma_col.end()
        );
        return nfg_profile_t {dist_row(rng), dist_col(rng)};
    }

    double logprob(nfg_profile_t value) const {
        if (value[0] >= sigma_row.size() || value[1] >= sigma_col.size())
            return -std::numeric_limits<double>::infinity();
        // finite-lambda QRE has full support, but clamp for safety
        constexpr double eps = 1e-300;
        return std::log(std::max(sigma_row[value[0]], eps))
             + std::log(std::max(sigma_col[value[1]], eps));
    }

    std::string string() const {
        std::stringstream ss;
        ss << "NormalFormGame(lambda=" << lambda << ", converged="
           << (converged ? "true" : "false") << ", sigma_row=[";
        for (size_t a = 0; a != sigma_row.size(); ++a) {
            if (a != 0) ss << ",";
            ss << sigma_row[a];
        }
        ss << "], sigma_col=[";
        for (size_t b = 0; b != sigma_col.size(); ++b) {
            if (b != 0) ss << ",";
            ss << sigma_col[b];
        }
        ss << "])";
        return ss.str();
    }
};

template<> struct output_domain<NormalFormGame> { using value = discrete_<nfg_profile_t>; };
template<> struct arity<NormalFormGame> { static constexpr size_t value = 3; };
template<> struct input_types<NormalFormGame> {
    using value = std::tuple<std::vector<std::vector<double>>, std::vector<std::vector<double>>, double>;
};

struct Node {
    bool terminal = false;
    int player = 0;
    std::vector<double> payoffs;
    std::vector<std::string> actions;
    std::vector<std::shared_ptr<Node>> children;
    int eq_choice = -1;          // index of equilibrium action (decision nodes)

    static std::shared_ptr<Node> terminal_node(std::vector<double> p) {
        auto n = std::make_shared<Node>();
        n->terminal = true; n->payoffs = std::move(p);
        return n;
    }
    static std::shared_ptr<Node> decision(int player,
                                          std::vector<std::string> acts,
                                          std::vector<std::shared_ptr<Node>> kids) {
        auto n = std::make_shared<Node>();
        n->player = player; n->actions = std::move(acts); n->children = std::move(kids);
        return n;
    }
};

// Backward induction. Returns payoffs of the equilibrium path of the subtree.
// Appends chosen actions (for the tree rooted here) to `path`.
std::vector<double> solve(const std::shared_ptr<Node>& n, std::vector<std::string>* path) {
    if (n->terminal) return n->payoffs;

    std::vector<double> best;
    size_t best_i = 0;
    for (size_t i = 0; i < n->children.size(); ++i) {
        auto v = solve(n->children[i], path);
        if (best.empty() || v[n->player] > best[n->player]) { // acting player maximizes own payoff
            best = v;
            best_i = i;
        }
    }
    path->push_back(n->actions[best_i]);
    return best;
}

std::vector<double> annotate(const std::shared_ptr<Node>& n) {
    if (n->terminal) return n->payoffs;
    std::vector<double> best;
    size_t best_i = 0;
    for (size_t i = 0; i < n->children.size(); ++i) {
        auto v = annotate(n->children[i]);
        if (best.empty() || v[n->player] > best[n->player]) { best = v; best_i = i; }
    }
    n->eq_choice = static_cast<int>(best_i);
    return best;
}

std::vector<std::pair<int, std::string>> eq_path(const std::shared_ptr<Node>& root) {
    std::vector<std::pair<int, std::string>> path;
    if (!root->terminal && root->eq_choice < 0) annotate(root);
    auto n = root;
    while (!n->terminal) {
        path.emplace_back(n->player, n->actions[static_cast<size_t>(n->eq_choice)]);
        n = n->children[static_cast<size_t>(n->eq_choice)];
    }
    return path;
}


// Prints ONE complete line: prefix (ancestors) + connector (this edge) + payload.
// The parent supplies both; the child supplies the rest of its line. No one
// prints anyone else's prefix twice.
//
//   prefix     : continuation characters inherited from ancestors
//   conn       : this node's edge, e.g. "├─ take *─ " or "" for the root
//   on_eq      : is this node on the equilibrium path
//   is_last    : is this node the last child of its parent (fixes prefix for ITS children)
static void print_rec(const std::shared_ptr<Node>& n, const std::string& prefix,
                      const std::string& conn, bool on_eq, bool is_last) {
    printf("%s%s", prefix.c_str(), conn.c_str());

    if (n->terminal) {
        printf("%s[ ", on_eq ? "* " : "");
        for (size_t i = 0; i < n->payoffs.size(); ++i)
            printf("%s%g", i ? ", " : "", n->payoffs[i]);
        printf(" ]\n");
        return;
    }

    printf("(P%d)\n", n->player);

    // Children indent under our connector: keep drawing our vertical if we
    // are not the last sibling of OUR parent, blank otherwise.
    std::string child_prefix = prefix + (is_last ? "    " : "│   ");
    for (size_t i = 0; i < n->children.size(); ++i) {
        bool last = (i + 1 == n->children.size());
        bool eq = (static_cast<int>(i) == n->eq_choice);
        std::string c = (last ? "└─ " : "├─ ") + n->actions[i] + (eq ? " *─ " : " ── ");
        print_rec(n->children[i], child_prefix, c, eq, last);
    }
}

void print_tree(const std::shared_ptr<Node>& root) {
    if (root->eq_choice < 0 && !root->terminal) annotate(root);
    // Root gets an empty connector; it's trivially the "last" child of nothing,
    // so its children start with a clean prefix.
    print_rec(root, "", "", true, true);
}

using dynamic_play_t = std::vector<std::pair<int, std::string>>;

template<>
std::string stringify(dynamic_play_t t) {
    std::string out = "[ ";
    for (size_t ix = 0; ix != t.size(); ix++) {
        out += "(" + stringify(t[ix].first) + ", " + t[ix].second + ") ";
    }
    out += "]";
    return out;
}

struct DynamicGame : Distribution<DynamicGame, dynamic_play_t> {

    std::shared_ptr<Node> tree;
    dynamic_play_t eq;

    DynamicGame(std::shared_ptr<Node> tree) : tree(tree) {
        // effectively acts as a complicated constraint node
        // anything interesting happens here and is dictated by
        // payoffs and strucure; i.e., upstream randomness
        // the outcome of sample is deterministic and "log prob" is
        // essentially just a constraint evaluation
        eq = eq_path(tree);
    }

    template<typename... Vs>
    DynamicGame(std::variant<Vs...> tree) : 
        DynamicGame(std::get<std::shared_ptr<Node>>(tree)) {}

    std::string string() const {
        return "DynamicGame(...)";
    }

    template<typename RNG>
    dynamic_play_t sample(RNG& rng) {
        return eq;
    }

    double logprob(dynamic_play_t value) const {
        double lp = 0.0;
        double penalty = 10.0;
        lp -= (double) eq.size() - value.size();
        size_t min_size = (eq.size() < value.size()) ? eq.size() : value.size();
        for (size_t ix = 0; ix != min_size; ++ix) {
            if (eq[ix].first != value[ix].first) lp -= penalty;
            if (eq[ix].second != value[ix].second) lp -= penalty;
        }
        return lp;
    }

};

template<> struct output_domain<DynamicGame> { using value = discrete_<dynamic_play_t>; };
template<> struct arity<DynamicGame> { static constexpr size_t value = 1; };
template<> struct input_types<DynamicGame> { using value = std::tuple<std::shared_ptr<Node>>; };

#endif  // GAME_DISTRIBUTIONS_H